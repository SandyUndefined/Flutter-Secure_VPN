import React from "react";
import "./loader.scss";

const loader = () => {
  return (
    <div>
      <div class="loader"></div>
    </div>
  );
};

export default loader;
