// export const DEFAULT_URL = "http://localhost:8080";
export const LOGIN = `/api/login`;
export const Vpns = `/api/vpns`;
export const COUNTRIES = `/api/countries`;
export const ME = '/api/me';
export const USERS = '/api/users';

export const REGISTER = '/api/register';
