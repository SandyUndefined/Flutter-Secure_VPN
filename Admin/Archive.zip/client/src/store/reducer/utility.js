const updateObject = (oldObject, newData) => {
  return {
    ...oldObject,
    ...newData,
  };
};
export default updateObject;
